import csv
import sys
from collections import defaultdict

REQ_COLS = {"req_id"}
TC_COLS = {"tc_id", "req_id", "type"}
NEGATIVE = {"negative", "error", "invalid"}


def read_csv(path, required):
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        cols = {c.strip().lower() for c in (reader.fieldnames or [])}
        missing = required - cols
        if missing:
            sys.exit(f"{path}: missing column(s): {', '.join(sorted(missing))}")
        rows = [{k.strip().lower(): (v or "").strip() for k, v in r.items() if k} for r in reader]
    return rows


def main():
    if len(sys.argv) != 3:
        sys.exit("Usage: python coverage_audit.py requirements.csv testcases.csv\n"
                 "requirements.csv needs: req_id\n"
                 "testcases.csv needs: tc_id, req_id, type (positive/negative/boundary/...)")

    requirements = read_csv(sys.argv[1], REQ_COLS)
    testcases = read_csv(sys.argv[2], TC_COLS)

    req_ids = [r["req_id"].upper() for r in requirements if r["req_id"]]
    dupes = sorted({i for i in req_ids if req_ids.count(i) > 1})
    known = set(req_ids)

    kinds_by_req = defaultdict(set)
    for tc in testcases:
        kinds_by_req[tc["req_id"].upper()].add(tc["type"].lower())

    uncovered, weak, full = [], [], []
    for rid in dict.fromkeys(req_ids):  # unique, keep order
        kinds = kinds_by_req.get(rid, set())
        if not kinds:
            uncovered.append(rid)
        elif "positive" in kinds and kinds & NEGATIVE:
            full.append(rid)      # needs BOTH a positive and a negative test
        else:
            weak.append(rid)      # missing positive or negative path

    orphans = [tc["tc_id"] for tc in testcases if tc["req_id"].upper() not in known]

    total = len(uncovered) + len(weak) + len(full)
    pct = lambda n: (n / total * 100) if total else 0.0

    print("| Metric | Value |")
    print("|---|---|")
    print(f"| Total requirements | {total} |")
    print(f"| Fully covered (positive + negative) | {len(full)} ({pct(len(full)):.1f}%) |")
    print(f"| Weakly covered (partial) | {len(weak)} ({pct(len(weak)):.1f}%) |")
    print(f"| Uncovered | {len(uncovered)} ({pct(len(uncovered)):.1f}%) |")
    print(f"| Any coverage (full + weak) | {pct(len(full) + len(weak)):.1f}% |")
    print(f"\nUncovered : {', '.join(uncovered) or 'None'}")
    print(f"Weak      : {', '.join(weak) or 'None'}")
    print(f"Orphan TCs: {', '.join(orphans) or 'None'}")
    if dupes:
        print(f"WARNING duplicate requirement IDs: {', '.join(dupes)}")


if __name__ == "__main__":
    main()
