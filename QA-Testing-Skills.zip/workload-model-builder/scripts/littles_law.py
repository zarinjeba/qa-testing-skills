import argparse
import math


def positive(name, value, allow_none=True):
    if value is None and allow_none:
        return
    if value is None or value <= 0:
        raise SystemExit(f"error: {name} must be greater than 0 (got {value})")


def main():
    parser = argparse.ArgumentParser(description="Little's Law workload sizing (N = X * R)")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--arrival-rate", type=float, help="users arriving per second (X)")
    group.add_argument("--daily-users", type=float, help="total users per day")
    parser.add_argument("--peak-hour-percent", type=float, default=10.0,
                        help="ASSUMPTION: percent of daily users in the peak hour, 0-100 (default 10)")
    parser.add_argument("--session-seconds", type=float, required=True,
                        help="average session duration in seconds incl. think time (R)")
    parser.add_argument("--safety-factor", type=float, default=1.0,
                        help="ASSUMPTION: headroom multiplier >= 1, e.g. 1.5 = +50%%")
    args = parser.parse_args()

    positive("--arrival-rate", args.arrival_rate)
    positive("--daily-users", args.daily_users)
    positive("--session-seconds", args.session_seconds, allow_none=False)
    if not 0 < args.peak_hour_percent <= 100:
        raise SystemExit("error: --peak-hour-percent must be in (0, 100]")
    if args.safety_factor < 1:
        raise SystemExit("error: --safety-factor must be >= 1")

    if args.arrival_rate is not None:
        x = args.arrival_rate
        source = "given"
    else:
        peak_hour_users = args.daily_users * args.peak_hour_percent / 100.0
        x = peak_hour_users / 3600.0
        source = (f"{args.daily_users:.0f} daily users x {args.peak_hour_percent}% / 3600 s "
                  f"(peak-hour share is an assumption)")

    n = x * args.session_seconds
    n_headroom = n * args.safety_factor

    print(f"Arrival rate X          = {x:.4f} users/second [{source}]")
    print(f"Session duration R      = {args.session_seconds:.0f} seconds")
    print(f"Concurrent users N=X*R  = {n:.2f} -> {math.ceil(n)}")
    print(f"With safety factor {args.safety_factor}x = {n_headroom:.2f} -> {math.ceil(n_headroom)} virtual users to simulate")


if __name__ == "__main__":
    main()
